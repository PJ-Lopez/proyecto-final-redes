const mysql = require('mysql2'); 

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Lopezpedro529',
    database: 'tareas'
});

connection.connect(error => {
    if (error) {
        console.error("Error conectando a la base de datos: " + error.stack);
        return;
    }
    console.log("Conectado a MySQL como id " + connection.threadId);
});

module.exports = connection;