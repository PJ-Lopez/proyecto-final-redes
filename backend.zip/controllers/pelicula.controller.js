const PeliculaModel = require('../models/pelicula.model')

// Obtener todas las películas
exports.getPeliculas = async (req, res) => {
    try {
        const peliculas = await PeliculaModel.findAll()
        res.status(200).json(peliculas)
    } catch (error) {
        res.status(500).json({
            error: error,
            message: 'Error al obtener las películas'
        })
    }
};

// Obtener película por ID
exports.getPeliculaById = async (req, res) => {
    try {
        const id = req.params.id
        const pelicula = await PeliculaModel.findByPk(id)
        if (!pelicula) {
            return res.status(404).json({
                error: 'Película no encontrada en la base de datos'
            })
        }
        res.status(200).json(pelicula)
    } catch (error) {
        res.status(500).json({
            error: error,
            message: 'Error al obtener la película'
        })
    }
}

// Crear nueva película
exports.createPelicula = async (req, res) => {
    try {
        const { titulo, genero, duracion, clasificacion, horario } = req.body
        const pelicula = await PeliculaModel.create({
            titulo,
            genero,
            duracion,
            clasificacion,
            horario
        })
        res.status(201).json(pelicula)
    } catch (error) {
        res.status(500).json({
            error: error,
            message: 'Error al crear la película'
        })
    }
}

// Actualizar película
exports.updatePelicula = async (req, res) => {
    try {
        const id = req.params.id
        const pelicula = await PeliculaModel.findByPk(id)
        if (!pelicula) {
            return res.status(404).json({
                error: 'Película no encontrada en la base de datos'
            })
        }

        const { titulo, genero, duracion, clasificacion, horario } = req.body
        pelicula.titulo = titulo
        pelicula.genero = genero
        pelicula.duracion = duracion
        pelicula.clasificacion = clasificacion
        pelicula.horario = horario

        await pelicula.save()
        res.json(pelicula)
    } catch (error) {
        res.status(500).json({
            error: error,
            message: 'Error al actualizar la película'
        })
    }
}

// Eliminar película
exports.deletePelicula = async (req, res) => {
    try {
        const id = req.params.id
        const pelicula = await PeliculaModel.findByPk(id)
        if (!pelicula) {
            return res.status(404).json({
                error: 'Película no encontrada en la base de datos'
            })
        }

        await pelicula.destroy()
        res.status(200).json({
            message: 'Película eliminada correctamente'
        })
    } catch (error) {
        res.status(500).json({
            error: error,
            message: 'Error al eliminar la película'
        })
    }
}
